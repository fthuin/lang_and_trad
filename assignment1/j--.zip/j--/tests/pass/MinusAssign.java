package pass;

public class MinusAssign {
    public int minusAssign(int x, int y) {
        int newx = x;
        newx -= y;
        return newx;
    }
}
