package fail;

import java.lang.System;

public class Modulo {
    public static void main(String[] args) {
        System.out.println('a' % 0);
    }
}
