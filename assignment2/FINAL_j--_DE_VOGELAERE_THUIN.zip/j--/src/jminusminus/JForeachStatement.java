package jminusminus;

import static jminusminus.CLConstants.GOTO;

import java.util.ArrayList;

public class JForeachStatement extends JStatement {

    private JFormalParameter forParam;
    private JExpression array;
    private JStatement bodyStatement;
    
    private ArrayList<JStatement> initStatements;
    private JExpression condition;
    private JStatement variableAssignment;
    private ArrayList<JStatement> endStatements;

    /**
     * Construct an AST node for a foreach loop.
     * This new foreach will use the classical For loop.
     *
     * @param line
     *            line in which the expression occurs in the source file.
     * @param forParam
     *            the first part of the foreach loop: a FormalParameter.
     * @param expression
     *            the second part of the foreach loop: an Expression
     * @param statement
     *            the body.
     */
    public JForeachStatement(int line, JFormalParameter forParam,
                                    JExpression array,
                                    JStatement body) {
        super(line);
        this.forParam = forParam;
        this.array = array;
        this.bodyStatement = body;
        
        /**
         * DECLARATION PART OF A STANDARD FOR-LOOP
         */

        initStatements = new ArrayList<JStatement>(); // init the tmp variable and the param

        // Create index variable (to iterate)
        JVariable index = new JVariable(line, "__tmpVariable__"+ line);
        JVariable iterationVariable = new JVariable(line, forParam.name());
        // Fill tmpVariableDeclaratorList to generate initDeclarators
        ArrayList<JVariableDeclarator> tmpVariableDeclaratorList = new ArrayList<JVariableDeclarator>();
        tmpVariableDeclaratorList.add(new JVariableDeclarator(line, index.name(), Type.INT, new JLiteralInt(line, "0")));
        tmpVariableDeclaratorList.add(new JVariableDeclarator(line, forParam.name(), forParam.type(), null));
        // Generate initDeclarators
        initStatements.add(new JVariableDeclaration(line, new ArrayList<String>(), tmpVariableDeclaratorList));

        /**
         * CONDITION PART OF A STANDARD FOR-LOOP
         */

        // Get the length:
        JFieldSelection length = new JFieldSelection(line, array, "length");
        // iteratorVariable <= length
        JLessEqualOp lhs = new JLessEqualOp(line, index, length);
        // iteratorVariable == length
        JEqualOp equalOp = new JEqualOp(line, index, length);
        // ! iteratorVariable == length
        JExpression rhs = new JLogicalNotOp(line, equalOp);
        // iteratorVariable <= length ^ ! iteratorVariable == length
        condition = new JLogicalAndOp(line, lhs, rhs);
        
        /**
         * VARIABLE ASSIGNEMNEMENT BEFORE BODY
         */
        
        JArrayExpression value = new JArrayExpression(line, array, index);
        JAssignOp assignment = new JAssignOp(line, iterationVariable, value);
        assignment.isStatementExpression = true;
        variableAssignment = assignment;
        	
        /**
         * ITERATION PART OF A STANDARD FOR-LOOP
         */

        endStatements = new ArrayList<JStatement>();
        
        // Increment index
        endStatements.add(new JPreIncrementOp(line, index));
        ((JExpression) endStatements.get(0)).isStatementExpression = true;
    }

    /**
     * Analyze all 3 parts of foreach loop
     *
     * @param context
     *            context in which names are resolved.
     * @return the analyzed (and possibly rewritten) AST subtree.
     */
    public JAST analyze(Context context) {
    	/* Analyzation of the statement(s) */
        if (initStatements != null) {
            for (JStatement initStatement : initStatements) {
                initStatement.analyze(context);
            }
        }

        /* Analyzation of the condition */
        if (condition != null) {
            condition.analyze(context);
            condition.type().mustMatchExpected(line(), Type.BOOLEAN);
        }

        /* Analyzation of the statement(s) executed after each iteration */
        if (endStatements != null) {
            for (JStatement incr : endStatements) {
                incr.analyze(context);
            }
        }
        
        /* Analyzation of the variable assignment (iterationVariable)*/
        variableAssignment.analyze(context);

        /* Analyzation of the body of the loop */
        bodyStatement.analyze(context);
        return this;
    }

    public void codegen(CLEmitter output) {
    	/*
         * Code generation for initial statement
         */
        if (initStatements != null) {
            for (JStatement initStatement : initStatements){
            	initStatement.codegen(output);
            }
        }

        /* Code generation for the condition */
        String conditionalLabel = output.createLabel();
        String endLoopLabel = output.createLabel();
        output.addLabel(conditionalLabel);
        if (condition != null) {
            condition.codegen(output, endLoopLabel, false);
        }
        
        /* Code generation for the variable attribution*/
        variableAssignment.codegen(output);

        /* Code generation for the body */
        bodyStatement.codegen(output);

        /* Code generation for the statements executed after each iteration */
        if (endStatements != null) {
            for (JStatement endStatement : endStatements){
            	endStatement.codegen(output);
            }
        }

        /* Adding a branch to go back to the condition */
        output.addBranchInstruction(GOTO, conditionalLabel);

        /* Adding the label of the end of the loop */
        output.addLabel(endLoopLabel);
    }

    /**
     * a writeToStdOut like the other
     */
    public void writeToStdOut(PrettyPrinter p) {
        p.printf("<JForeachStatement line=\"%d\">\n", line());
        p.indentRight();
            p.println("<FormalParam>");
            p.indentRight();
                if (forParam != null)
                    forParam.writeToStdOut(p);
            p.indentLeft();
            p.println("</FormalParam>");
            p.println("<Expression>");
            p.indentRight();
                if (array != null)
                    array.writeToStdOut(p);
            p.indentLeft();
            p.println("</Expression>");
            p.println("<Statement>");
            p.indentRight();
                bodyStatement.writeToStdOut(p);
            p.indentLeft();
            p.println("</Statement>");
        p.indentLeft();
        p.println("</JForeachStatement>");
    }

}
