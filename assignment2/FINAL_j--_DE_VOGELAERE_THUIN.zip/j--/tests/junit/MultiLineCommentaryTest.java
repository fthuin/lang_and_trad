package junit;

import junit.framework.TestCase;
import pass.MultiLineCommentary;

public class MultiLineCommentaryTest extends TestCase {
	
	private MultiLineCommentary com;

    protected void setUp() throws Exception {
        super.setUp();
        com = new MultiLineCommentary();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testDivide() {
        this.assertEquals(com.isCommentary(), true);
        this.assertEquals(com.isNotCommentary(), false);
    }
}