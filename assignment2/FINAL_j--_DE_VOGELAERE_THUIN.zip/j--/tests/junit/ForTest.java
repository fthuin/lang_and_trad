package junit;

import junit.framework.TestCase;
import pass.For;

public class ForTest extends TestCase {
	
	private For com;

    protected void setUp() throws Exception {
        super.setUp();
        com = new For();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testFor() {
    	int[] tab = {2, 3, 4, 5};
        this.assertEquals(com.testBasicFor(10, 1), 10);
        this.assertEquals(com.testBasicFor(10, 2), 5);
        this.assertEquals(com.testBasicFor(10, 5), 2);
        this.assertEquals(com.testBasicForeach(tab), 14);
    }
}
