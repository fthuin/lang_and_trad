package fail;

public class ForError {
	public static runThrough() {
		for (int i = 0 , i <= 10 ; i += 1) {
			System.out.println("You failed everything in your life.");
	}
	
	public static void main(String[] args) {
		runThrough();
	}
}
