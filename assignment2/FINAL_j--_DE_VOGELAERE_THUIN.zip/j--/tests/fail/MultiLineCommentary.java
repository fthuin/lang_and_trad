package fail;

public class MultiLineCommentary {

	public boolean MultiLineCommentary(){
		/*
		 * Ceci est un commentaires
		 * /* /* /* /* /* /* /* /* 
		 
		return true;
	}
}
