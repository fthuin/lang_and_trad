package pass;

import java.lang.System;

public class For {
	
	private int runThrough() {
		for(;;);
		
		for(int i = 0; i == 10; ++i);
		
		for(final int j = 0; j == 10; ++j);
		
		for(i = 0, i = 3; i == 10; ++i);
			
		for(final int l = 0, z= 2; l == 10; ++l);
		
		for(int m = 0; m == 10; ++m, ++m);
		
		for(final int n = 0; l == 10; ++n, ++n);
		
		for(int o = 0; o == 5; ++o){
			++o;
		}
		
		int a = 0;
		int[] tab = {0, 1, 2};
		
		for (int q : tab) {
            i += a;
        }
		
        return 0;
	}
	
	public int testBasicFor(int max, int step){
		int a = 0;
		for(int i = 0; !(i == max); i += step){
			++a;
		}
		return a;
	}
	
	public int testBasicForeach(int[] tab){
		int a = 0;
		for(int i : tab){
			a += i;
		}
		return a;
	}
}
