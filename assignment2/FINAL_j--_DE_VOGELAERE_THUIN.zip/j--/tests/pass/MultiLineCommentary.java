package pass;

public class MultiLineCommentary {

	public boolean isCommentary(){
		/*
		 * Ceci est un commentaires
		 * /* /* /* /* /* /* /* /* 
		 * 
		return false;
		
		 * Ceci est un second commentaire
		 */
		return true;
	}
	
	public boolean isNotCommentary(){
		/*
		 * Ceci est un commentaires
		 * /* /* /* /* /* /* /* /* 
		 */ 
		return false;
		
		 /* Ceci est un second commentaire
		 */
		return true;
	}
}
