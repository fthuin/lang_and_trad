package errors;

public class ParseError extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ParseError() {
		super("Parse error !");
	}
} 