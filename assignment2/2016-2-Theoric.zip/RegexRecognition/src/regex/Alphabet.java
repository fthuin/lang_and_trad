package regex;

/**
 * DO NOT MODIFY
 */
public class Alphabet {

	public final static String A = "a";
	public final static String B = "b";
	public final static String C = "c";
}
