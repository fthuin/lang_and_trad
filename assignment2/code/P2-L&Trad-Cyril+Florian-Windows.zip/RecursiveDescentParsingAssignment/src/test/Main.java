package test;

import errors.ParseError;
import grammar.Generator;
import grammar.Parser;

public class Main {

	public static void main(String[] args) throws ParseError{
		
		Generator gen = new Generator(50);
		Parser par = new Parser();
		
		String[] generated = gen.generate(50);
		//String[] generated = {"false"};
		
		for(String e : generated){
			System.out.print(e + " ");
		}
		System.out.println("");
		
		System.out.println(par.parse(generated));
	}
}
