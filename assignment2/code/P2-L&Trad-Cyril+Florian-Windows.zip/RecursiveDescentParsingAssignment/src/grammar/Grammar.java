package grammar;

/**
 * DO NOT MODIFY
 */
public class Grammar {
	/**
	 * Grammar 
	 * E -> T E1
	 * E1 -> and T E1 | nand T E1 | epsilon
	 * T -> F T1 
	 * T1 -> or F T1 | nor F T1 | epsilon 
	 * F -> ( E ) | !F | id 
	 * id -> true | false
	 */

	public final static String AND = "and";
	public final static String NAND = "nand";
	public final static String OR = "or";
	public final static String NOR = "nor";
	public final static String NEG = "!";
	public final static String LEFTPAR = "(";
	public final static String RIGHTPAR = ")";
	public final static String TRUE = "true";
	public final static String FALSE = "false";

}
