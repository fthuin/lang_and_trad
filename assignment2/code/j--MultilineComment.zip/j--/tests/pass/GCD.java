package pass;

public class GCD {
    public int gcd(int x, int y) {
		if(x == 0) return 0;
		if(y == 0) return 0;
        while(!(x == y)) {
			if(x > y) { 
				x -= y;
			}
			else {
				y -= x;
			}
		}
		return x;
    }
}

