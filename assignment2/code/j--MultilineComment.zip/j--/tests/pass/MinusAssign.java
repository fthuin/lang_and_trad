
package pass;

public class MinusAssign {
	public int minusAssign(int x, int y) {
		x -= y;
		return x;
	}
}

