package fail;

import java.lang.System;

public class MinusAssign {
    public static void main(String[] args) {
		int a = 0;
        System.out.println(a -= "42");
    }
}

