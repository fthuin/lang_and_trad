package junit;

import junit.framework.TestCase;
import pass.MinusAssign;

public class MinusAssignTest extends TestCase {
    private MinusAssign op;

    protected void setUp() throws Exception {
        super.setUp();
        op = new MinusAssign();
    }

    protected void tearDown() throws Exception {
        super.tearDown();
    }

    public void testMinusAssign() {
        this.assertEquals(op.minusAssign(0,42), -42);
        this.assertEquals(op.minusAssign(42,0), 42);
        this.assertEquals(op.minusAssign(42,3), 39);
        this.assertEquals(op.minusAssign(3,42), -39);
    }
}


